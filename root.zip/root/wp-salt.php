<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'xEf3cNbnDawhTo6qthFqRzJ3Lof7VdSedd9X7AYjfaaWP8wpyuU7wDCQMpUQyaRx');
define('SECURE_AUTH_KEY',  'M4ddqx5QTx72J2Cxobc7UrH6HnbEEIvpb107d8EJvUCeApF9Jix1TFq1ILfqHMXf');
define('LOGGED_IN_KEY',    '6f5FDRuHEAqVXK70gX2d7zt0V24hbuWp0tyyxXUQ8y1CTsPPwV0SUq0UMSeX3Ah6');
define('NONCE_KEY',        '3dcfepyNV0wQAjCgsUTf0ocnKpfsecwovaJbpdzBWvQG78c1YS44nQeNmhYwmezv');
define('AUTH_SALT',        'n2ScqBNCV0UJztI4etS5LXDTj08JwVe3BqxBH1yhgiMjG6XqaD34oonjByF1VCPn');
define('SECURE_AUTH_SALT', 'CrPGRIqUF18IYvaSvN92Pzyod5MCTEbTUDrsjmALxnvNMnYTLL7dtiNiqwNnqHwL');
define('LOGGED_IN_SALT',   '22RHDn3atajp90uBca4GeLIhHxc3zEawdzbfotM7uzre52wvt0eE4eg9IryPLHdq');
define('NONCE_SALT',       'IazgG0HzKEI6vcRqodyYxBIMJh2dopLruCnwPnVrW9dJKIv7DoiTIG1vSq8NtIvB');
