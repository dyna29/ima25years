<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <meta name="viewport" content="width=device-width, minimum-scale=1.0, initial-scale=1.0">
        <meta http-equiv="refresh" content="0;url=https://goo.gl/nG9iL2" />
        <?php wp_head(); ?>
    </head>