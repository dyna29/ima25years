<?php
/*
 *  Theme's Widgets
 */
include(get_template_directory().'/inc/widgets/latest-post-type.php');