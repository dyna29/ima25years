<?php
require_once get_template_directory().'/inc/meta/page-metadata.php';
require_once get_template_directory().'/inc/meta/post-metadata.php';