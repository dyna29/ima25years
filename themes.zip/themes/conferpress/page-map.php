<html <?php language_attributes(); ?>>
    <head> 
        <meta http-equiv="refresh" content="0;url=https://goo.gl/maps/zYSGgLuWMSJ2" />
        <?php wp_head(); ?>
    </head>