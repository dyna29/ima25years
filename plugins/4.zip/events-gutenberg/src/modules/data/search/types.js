export const ADD_BLOCK = 'ADD_BLOCK';
export const SET_TERM = 'SET_TERM';

export const SET_SEARCH_POST_TYPE = 'SET_SEARCH_POST_TYPE';

export const SEARCH = 'SEARCH';
export const SET_SEARCH_IS_LOADING = 'SET_SEARCH_IS_LOADING';

export const SET_RESULTS = 'SET_RESULTS';
export const ADD_RESULTS = 'ADD_RESULTS';

export const SET_PAGE = 'SET_PAGE';
export const SET_TOTAL_PAGES = 'SET_TOTAL_PAGES';

export const CLEAR_BLOCK = 'CLEAR_BLOCK';
