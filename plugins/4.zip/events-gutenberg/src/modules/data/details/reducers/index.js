export { default as details } from './details';
