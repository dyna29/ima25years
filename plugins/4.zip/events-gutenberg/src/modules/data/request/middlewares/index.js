export { default as wpRequest } from './wp-request';
