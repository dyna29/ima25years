export { default as TEC } from './tec';
