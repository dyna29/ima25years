<?php $event_id = $this->get( 'post_id' ); ?>
<?php echo tribe_event_featured_image( $event_id, 'full', false );