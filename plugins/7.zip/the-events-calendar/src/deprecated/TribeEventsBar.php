<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Bar' );


	class TribeEventsBar extends Tribe__Events__Bar {

	}