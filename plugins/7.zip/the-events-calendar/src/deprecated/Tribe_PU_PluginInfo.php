<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__PUE__Plugin_Info' );


	class Tribe_PU_PluginInfo extends Tribe__PUE__Plugin_Info {

	}