<?php global $global_devide_item ?>
<div class="cd-mac cd-fill-parent cd-center">
  <div class="cd-top"></div>
  <div class="cd-bottom"></div>
  <div class="cd-camera"></div>
  <div class="cd-notch"></div>
  <div class="cd-screen">
    <?php echo iAppShowcase::ias_devide_content($global_devide_item); ?>
  </div>
</div>