<?php global $global_devide_item ?>
<div class="cd-watch cd-fill-parent cd-center <?php /*echo $global_devide_item['devide_color_iphone6']?'cd-'.$global_devide_item['devide_color_iphone6']:'cd-silver';*/ ?> cd-gold cd-linked-band">
  <div class="cd-bracket"></div>
  <div class="cd-top-band"></div>
  <div class="cd-bottom-band"></div>
  <div class="cd-body"></div>
  <div class="cd-crown"></div>
  <div class="cd-button"></div>
  <div class="cd-screen">
    <?php echo iAppShowcase::ias_devide_content($global_devide_item); ?>
  </div>
</div>