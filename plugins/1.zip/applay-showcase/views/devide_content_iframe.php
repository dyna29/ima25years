<?php global $global_devide_item; ?>
<div class="ias-devide-content ias-devide-content-iframe">
<iframe width="100%" height="100%" src="<?php echo $global_devide_item['content_iframe'] ?>" frameborder="0"></iframe>
</div>